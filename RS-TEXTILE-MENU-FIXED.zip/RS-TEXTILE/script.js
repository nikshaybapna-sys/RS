// RS TEXTILE - safe site interactions

// Hero slider
(function () {
    const slides = document.querySelectorAll(".slide");
    if (slides.length > 1) {
        let index = 0;
        slides[0].classList.add("active");
        setInterval(function () {
            slides[index].classList.remove("active");
            index = (index + 1) % slides.length;
            slides[index].classList.add("active");
        }, 4000);
    }
})();

// Testimonial slider
(function () {
    const testimonials = document.querySelectorAll(".testimonial");
    if (testimonials.length > 1) {
        let index = 0;
        testimonials[0].classList.add("active");
        setInterval(function () {
            testimonials[index].classList.remove("active");
            index = (index + 1) % testimonials.length;
            testimonials[index].classList.add("active");
        }, 4000);
    }
})();

// Product search
(function () {
    const search = document.getElementById("search");
    if (!search) return;
    search.addEventListener("keyup", function () {
        const value = search.value.toLowerCase();
        document.querySelectorAll(".product-card").forEach(function (card) {
            card.style.display = card.innerText.toLowerCase().includes(value) ? "block" : "none";
        });
    });
})();

// Product filter
window.filterProducts = function (category, button) {
    const cards = document.querySelectorAll(".product-card");
    const buttons = document.querySelectorAll(".filter-buttons button");
    buttons.forEach(function (btn) { btn.classList.remove("active"); });
    if (button) button.classList.add("active");
    let count = 0;
    cards.forEach(function (card) {
        const show = category === "all" || card.classList.contains(category);
        card.style.display = show ? "block" : "none";
        if (show) count++;
    });
    const counter = document.getElementById("product-count");
    if (counter) counter.innerText = "Showing " + count + " Product(s)";
};

// EmailJS form
(function () {
    const form = document.getElementById("contact-form");
    if (!form || typeof emailjs === "undefined") return;
    try {
        emailjs.init({ publicKey: "kvjBFweiu3hBn2mCv" });
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            emailjs.sendForm("nikshaybapna@gmail.com", "template_txwasxo", this)
                .then(function () { alert("Inquiry Sent Successfully!"); form.reset(); })
                .catch(function (error) { console.log(error); alert("Failed to Send Inquiry."); });
        });
    } catch (e) { console.log(e); }
})();

// FAQ
document.querySelectorAll(".faq-question").forEach(function (question) {
    question.addEventListener("click", function () {
        const answer = question.nextElementSibling;
        if (answer) answer.style.display = answer.style.display === "block" ? "none" : "block";
    });
});

// Scroll to top
(function () {
    const scrollBtn = document.getElementById("scrollTopBtn");
    if (!scrollBtn) return;
    window.addEventListener("scroll", function () {
        scrollBtn.style.display = window.scrollY > 300 ? "block" : "none";
    });
    scrollBtn.addEventListener("click", function () {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });
})();
